#include "operation.h"
#include "double.h"

char *tisi[100] = {"请输入商品编号","请输入商品名",
					"请输入进价","请输入售价","进货数量"
					};

//购买商品
void sub_goods(char a[] ,char b[])
{
	FILE *fp = NULL;//仓库
	list_poin add_head;
	int quan = 0;
	list_poin new;
	list_poin head;
	user_poin user;
	int num;
	int amount;

	user = init_User(user);

	head = init_Warehouse(head);
	add_head = creat_head_node();
	show_zheng_custom(head,0);

	printfs_blue("按 任意字母 退出输入\n");
	while(1)
	{
		printf("输入购买\n");
		printfs_red("商品编号 ");
		printf("即可\n");
		if(!scanf("%d",&num))
			break;
		getchar();
		printf("输入数量\n");
		if(!scanf("%d",&amount))
			break;
		getchar();
		

		new = buy_goods(head,num);
		if(new == NULL)
		{
			printf("没有该商品，重新输入\n");
			continue;
		}
		

 		if(new->amount < amount)
 		{
 			printf("没有这么多货\n");
 			printf("请重新输入\n");
 			continue;
 		}
 		new->amount = amount;

 		num_change(head, num, amount,0);

 		link_node(add_head, new);

	}
	//将购买后仓库的信息 写入仓库
	write_txt(head , 0);

  	show_zheng_custom(add_head,1);	
  	//将购物车的信息 写入进出货单 2是加
  	write_txt(add_head , 2);
  	//金钱计算


  	if(login_coupon(user,a, b) != 0)
  	{
  		printfs_blue("shiyong");
  		quan = login_coupon_return(user,a, b);
  	}
  	
  	if(price_sub(add_head,0) <= quan)
	{
		printfs_red("nibencimianfei");
	}
  	else
  	{
  		login_coupon_sub(user,a, b,quan,1);
  		float sum = price_sub(add_head,0) - quan;
  		printf("%0.1f\n", sum);
  		fund_change(sum,1);
  	}

  	write_user_txt(user);
 	while(getchar() != 'q');
 	system("clear");
 	Consumer_login_menu();

}
//进货
void add_supermaket()
{
	FILE *fp = NULL; //仓库
	list_poin add_head;
	list_poin head;
	list_poin new;
	float bid;
	int num, amount;

	head = init_Warehouse(head);
	add_head = creat_head_node();

	fp = fopen("./log/splace_in.txt", "r");
	if(fp == NULL)
 	{
 		printf("打开失败\n");
 	}
 	show_zheng_fu(head);
 	printf("=====输入 任意字母 退出======\n");
 	printf("\n");
 	//输入进货商品编号，数量
 	while(1)
 	{ 		
 		printfs_red("输入进货商品编号\n");
 		if(!scanf("%d",&num))
 			break;
 		getchar();
 		
 		printf("输入该商品数量\n");
 		if(!scanf("%d",&amount))
 			break;
 		getchar();

 		new = buy_goods(head,num);
		if(new == NULL)
		{
			printf("没有该商品，重新输入\n");
			continue;
		}
		new->amount = amount;

		num_change(head, num, amount,1);

 		link_node(add_head, new);
 	}
 	 //将进货单 写入链表 ，写入add_txt
 	write_txt(add_head, 1);
 	show_zheng_fu(add_head);
 	//进货后将 信息写入仓库
 	write_txt(head, 0);

 	float sum = price_sub(add_head,1);
 	fund_change(sum,0);
 	printf("进货为价格为====%0.1f\n", sum);
 	fclose(fp);

 	printf("完成操作返回上一层,请按q\n");
 	while(getchar() != 'q');
 	keeper_menu();

}


void chang_price()
{	
	FILE *fp = NULL; //仓库
	list_poin head;
	head = init_Warehouse(head);
	int num;
	float price;
	fp = fopen("./log/splace_in.txt", "r");
	show_zheng_fu(head);
	printfs_red("按 任意字母 退出\n");
	while(1)
	{
		printfs_blue("输入进货商品编号\n");
 		if(!scanf("%d",&num))
 			break;
 		getchar();
 		
 		printf("输入该商品售价\n");
 		if(!scanf("%f",&price))
 			break;
 		getchar();

 		sho_change(head, num,price);
	}
	write_txt(head, 0);
	fclose(fp);
	printf("完成操作返回上一层,请按q\n");
 	while(getchar() != 'q');

 	keeper_menu();

}




int  login_user(user_poin head, char a[], char b[])
{
	user_poin p = head;
	while(p->next != head)
	{
		p = p->next;
		if((!strcmp(p->user_name, a)) && (!strcmp(p->user_password, b)))
			return 1;
	}
 	printf("没有该用户，请重新输入\n");

	return 0;
}


//资金查询
void look_fund()
{
	system("clear");
	FILE *fp = fopen("./log/fund.txt", "r");
	float a;
	char c;
	fscanf(fp, "%f", &a);
	printf("现有资金为\n");
	printf("%0.1f\n", a);
	printf("							q 返回上一层\n");

	while( getchar() != 'q');
	
	keeper_menu();

	fclose(fp);
}

//账单查询
//i参数
//		1：进货账单
//		0：出货账单
void look_check(int i)
{
	system("clear");
	FILE *fp; //= fopen("./log/add_txt.txt", "r");
	switch(i)
	{
		case 1:fp = fopen("./log/add_txt.txt", "r");break;
		case 2:fp = fopen("./log/sub_txt.txt", "r");break;
	}
	
	int a,  d;
	float b, c, e;
	char str[30];
	char str_time[5][15];
	printf("编号 名字 进价 售价 变更数量  进/售总价   时间\n");
	while(1)
	{
		if(fscanf(fp, "%d %s %f %f %d %f  %s %s %s %s %s\n", 
			&(a), str, &(b), &(c), &(d), &(e), str_time[0],str_time[1],
			str_time[2],str_time[3],str_time[4]) ==EOF  )
		{
			break;
		}
		printf("%d  %s %0.1f\t %0.1f\t%d\t %0.1f\t%s%s%s%s%s\n", a,str,b,c,d,e,str_time[0],
			str_time[1],str_time[2],str_time[3],str_time[4]);
	}

	find_fund();
	printf("\n");
	printf("完成操作返回上一层,请按q");
 	while(getchar() != 'q');
 	keeper_menu();
}






//注册用户
void enroll()
{
	user_poin user;
	user = init_User(user);
	FILE *fp = fopen("./log/user_login.txt","a+");
	char z[50];
	char mima[50];
	char mima_temp[50];
	char c;
	printfs_red("=============欢迎注册============");
	int temp = 0;


	while(1)
	{
		printf("请输入用户名\n");
		printf("以空格或者回车结束输入！！！！\n");
		scanf("%s",z);

		//判断是否有该用户
		if(user_again(user,z))
		{
			temp = 1;
			
			break;
		}

		printf("请输入密码\n");
		printf("以空格或者回车结束输入！！！！\n");
		scanf("%s",mima);
		printf("请再次确认密码\n");
		printf("以空格或者回车结束输入！！！！\n");
		scanf("%s",mima_temp);
		//创建成功
		if(!strcmp(mima_temp,mima))
		{
			printf("用户名：");
			printf("%s\n", z);
			printf("密码：");
			printf("%s\n", mima);
			fprintf(fp, "%s %s %d %d\n", z, mima, 0,0);
			printfs_blue("创建成功，q 返回上一层");
			while(scanf("%c",&c) )
			{
				if(c == 'q')
					break;
			}
			break;
		}
		//创建失败
		else
		{
			printf("\n");
		 	printfs_blue("密码不一致,请出重新输入\n");
		 	printf("\n");
			continue;
		}
	}
	if(temp)
	{
		printf("该用户已经被注册\n");
		printfs_blue("创建成功，q 返回上一层");
			while(scanf("%c",&c) )
			{
				if(c == 'q')
					break;
			}
	}
	
	fclose(fp);
	Consumer_login_menu();
}



void sale_menu()
{
	float sa = 0;
	list_poin head;
	list_poin p ;
	int nu = 1;

	char c;
	printf("输入价格调整系数！！\n");
	
	scanf("%f", &sa);
	head = init_Warehouse(head);
	show_zheng_fu(head);
	p = head;
    while(p->next != head)
    {
    	p = p->next;
    	p->price = (p->price * sa);
    	if(p->price == 0)
    		nu = 0;
    }
	printf("价格调整完成：\n");
	show_zheng_fu(head);
	if(nu)
	{
		write_txt(head, 0);
		printfs_blue("完成操作返回上一层,请按q\n");
	}
	else
	{
		printfs_red("有价格 被调到了 非正数 \n");
		printfs_blue("操作失败！！！");
	}	
	while(scanf("%c",&c) )
	{
		if(c == 'q')
			keeper_menu();
	}
}

void Coupon(char a[] ,char b[])
{
	printfs_blue("==================================");
	printfs_red("===================================");
	char temp;
	int i = 0;
	int j = 0;
	user_poin user;
	user = init_User(user);
	printfs_blue("输入任意键 非 ‘q’ 键进行疯抢\n");
	srand(time(NULL)); //随机数
	while(1)
	{
		temp=getc(stdin);
		i = rand()%5;
		i = rand()%6;
		//printf("%c\n" ,temp);
		if (i == j)
		{
			printf("恭喜你获得一张，一元券\n");
			printfs_blue("输入任意键 非 ‘q’ 键进行疯抢\n");
			login_coupon_sub(user,a, b,1,0);
		}
		else
		{
			printf("抱歉没有抢到，请继续\n");
			printfs_blue("输入任意键 非 ‘q’ 键进行疯抢\n");
		}
		
		if(temp == 'q')
			break;
		getchar();
	}
	write_user_txt(user);
	Consumer_menu(a,b);
}



void add_goods()
{
	printfs_red("功能因为无法输入中文，暂不开通！！！\n");

	printf("完成操作返回上一层,请按q\n");
 	while(getchar() != 'q');
 	keeper_menu();
}