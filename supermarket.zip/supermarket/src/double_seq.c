
#include "double.h"

list_poin creat_head_node()
{
	list_poin  p;
	p = malloc(sizeof(listnode));
	p->next = p;
	p->prev = p;

	return p;
}

list_poin creat_node()
{
	list_poin new = malloc(sizeof(listnode));
	
	if(!new)
	{
		printf("创建节点失败！\n");
		return NULL;
	}

	new->next = new->prev = new;
	return new;
}

int link_node(list_poin head,list_poin temp)
{
	list_poin p = head;
	while(p->next != head)
	{
		p = p->next;
	}
	
	temp->prev = p;
	temp->next =p->next;
	temp->next->prev = temp;
	p->next = temp;

	return 0;
}



int show_zheng_fu(list_poin head)
{
	list_poin p;
	p = head;
	printf("====正序排列=====\n");
	printf("编号    商品名    进价   售价   数量\n");
	while(p->next != head)
	{
		p = p->next;
		printf("%1d 	", p->num);
		printf("%5s 	", p->good_name);
		printf("%0.1f 	", p->bid);
		printf("%0.1f 	", p->price);
		printf("%5d 	", p->amount);
		printf("\n");

	}
	return 0;
}
//给用户展示的商品链表
//i参数：
// 0：显示给顾客看的 货物表
// 1：显示  顾客买后 的确认表
int show_zheng_custom(list_poin head,int i)
{
	list_poin p;
	p = head;
	printf("====正序排列=====\n");
	printf("编号    商品名    售价   数量\n");
	while(p->next != head)
	{
		p = p->next;
		printf("%1d 	", p->num);
		printf("%5s 	", p->good_name);
		printf("%0.1f 	", p->price);
		printf("%5d 	", p->amount);
		printf("\n");
	}
	if(i)
		printf("总价：");
	return 0;
}


user_poin creat_head_user()
{
	user_poin  p;
	p = malloc(sizeof(user_mi));
	p->next = p;

	return p;
}

user_poin creat_node_user()
{
	user_poin new = malloc(sizeof(user_mi));
	
	if(!new)
	{
		printf("创建节点失败！\n");
		return NULL;
	}
	new->one_coupon = 0;
	new->hund_coupon = 0;

	new->next = new;
	return new;
}
int link_node_user(user_poin head,user_poin temp)
{
	user_poin p = head;
	while(p->next != head)
	{
		p = p->next;
	}
	temp->next =p->next;
	p->next = temp;
	return 0;
}
int show_zheng_user(user_poin head)
{
	user_poin p =head;
	
	while(p->next != head)
	{
		p = p->next;
		printf("%s 	", p->user_name);
		printf("%s 	", p->user_password);
		printf("%d 	", p->one_coupon);
		printf("%d 	", p->hund_coupon);
		printf("\n");
	}
	return 0;

}


