#include <menu.h>
//主界面
void menu_main()
{
	system("clear");
	int iden;
	printf("==========================欢迎来到超市购物==========================\n");
	printf("\n");
	printf("\n");
	printf("\n");
	printfs_red("			1.管理者登录\n");
	printfs_blue("			2.游客登录\n");
	printf("			3.退出\n");
	printf("\n");
	printf("\n");

	while(1)
	{
		scanf("%d", &iden);
		while(getchar() != '\n');
		switch(iden)
		{
			case 1:keeper_login_menu();break;
			case 2:Consumer_login_menu();break;
			case 3:exit(1);
			default:printf("请输入正确选项\n");break;
		}
	}
	
}
//管理者登录界面
void keeper_login_menu()
{
	system("clear");
	printf("===============管理者 登录 界面===============\n");
	printf("\n");
	printf("\n");
	printf("\n");

	keeper_login();
}
//管理者界面
void keeper_menu()
{
	int opera;	
	system("clear");
	printfs_red("==========================管理者界面=========================\n");
	printfs_blue("			1.添加商品\n");
	printfs_blue("			2.进货地添加商品\n");
	printfs_blue("			3.修改单个商品售价\n");
	printfs_blue("			4.查看进货账单\n");
	printfs_blue("			5.查看消费账单\n");
	printfs_blue("			6.查看资金\n");
	printfs_red("			7.修改价格(打折操作)\n");
	printf("			8.退出\n");
	printf("\n");
	printf("\n");

	while(1)
	{
		scanf("%d",&opera);
		while(getchar()!='\n');
		switch(opera)
		{
			case 1:add_goods();break;
			case 2:add_supermaket();break;
			case 3:chang_price();break;
			case 4:look_check(1);break;
			case 5:look_check(2); break;
			case 6:look_fund(); break;
			case 7:sale_menu(); break;
			case 8:menu_main();break;
			default: printf("请输入正确选项\n");break;
		}
	}
	

}



//用户登录界面
void Consumer_login_menu()
{
	system("clear");
	printfs_red("========================用户登录界面===============\n");
	printfs_blue("========================1.输入账户===============\n");
	printfs_blue("========================2.注册账户===============\n");
	printf("========================3.退出===============\n");
	printf("\n");
	printf("\n");
	printf("\n");
	int opera;

	while(1)
	{
		scanf("%d",&opera);
		while(getchar()!='\n');
		switch(opera)
		{
			case 1:Consumer_login();break;
			 case 2:enroll();break;
			case 3:exit(1);break;
			default : printf("请输入正确选项\n");break;
		}
	}

}

//用户使用界面
void Consumer_menu(char a[] ,char b[])
{
	int opera;	
	system("clear");
	printf("===============用户界面===============\n");
	printf("====你好！%s 用户,欢迎光临============\n", a);
	printfs_red("			1.购买商品\n");
	printfs_red("			2.购物券抢购\n");
	printf("			3.退出\n");
	printf("\n");
	printf("\n");

	while(1)
	{
		scanf("%d",&opera);
		while(getchar()!='\n');
		switch(opera)
		{
			case 1:sub_goods(a,b);break;
			case 2:Coupon(a,b);break;
			case 3:menu_main();break;
			default:printf("请输入正确选项\n");break;
		}
	}
}

//用户登录操作
void Consumer_login()
{
	user_poin user_head;
	char mima[2][20];
	char temp[100];
	int m = 0;
	int prove;

 	printf("请输入账号\n");
 	//fgets(mima[0], 20,stdin);
 	scanf("%s",mima[0]);
 	printf("请输入密码\n");
 	getchar();
 	scanf("%s",mima[1]);
 	getchar();
 	user_head = init_User(user_head);

 	printf("==============\n");
 	show_zheng_user(user_head);
 	prove = login_user(user_head ,mima[0],mima[1]);
 	

 	if(prove == 1 )
 	{
 		Consumer_menu(mima[0],mima[1]);
 	}
 	else
 	{
 		printf("请重新输入\n");
 		//sleep(1);
 		Consumer_login_menu();
 	}

}

//管理者登录操作
void keeper_login()
{
	char user[2][20];
	char mima[2][20];
	char temp[100];
	int m = 0;
	FILE *fp;
	fp = fopen("./log/boss_login.txt","r");

	if(fp == NULL)
 	{
 		printf("打开失败\n");
 	}

	fscanf(fp, "%s %s",temp, user[0]);	
	fseek(fp, ftell(fp)+1, SEEK_SET);
	fscanf(fp, "%s %s",temp, user[1]);
 	
 	printf("请输入账号\n");
 	fgets(mima[0], 20,stdin);
 	
 	printf("请输入密码\n");
 	fgets(mima[1], 20,stdin);
 	//字符串拼接
 	sprintf(user[0], "%s%s", user[0],"\n");
 	sprintf(user[1], "%s%s", user[1],"\n");
 	if((!strcmp(mima[0] , user[0])) && (!strcmp(mima[1], user[1])))
	{
		m = 1;
	}
	fclose(fp);
	if(m)
	keeper_menu();
	else
	menu_main();
}






void printfs_red(char a[])
{
	printf("\033[1;31m");
	printf("%s" ,a);
	printf("\033[0m\n");
}

void printfs_blue(char a[])
{
	printf("\033[1;34m");
	printf("%s" ,a);
	printf("\033[0m\n");
}

//隐藏光标 提示语句
void hide_cursor()
{
	printf("\033[?25l   \n");
	printf("完成操作返回上一层,请按q\n");
 	while(getchar() != 'q');
	printf("\33[?25h    \n");
}
