#include "base.h"
#define size 10
#define block 10
//初始化用户
user_poin init_User( user_poin user_head)
{
	FILE *fp = fopen("./log/user_login.txt", "r");
	user_head = creat_head_user();
	int i;

	while(1)
	{
		user_poin new = creat_node_user();
		if(fscanf(fp, "%s %s %d %d\n", 
			new->user_name, new->user_password, &(new->one_coupon),&(new->hund_coupon))
			==EOF  )
		{
			break;
		}
		link_node_user(user_head, new);
	}
	fclose(fp);
	return user_head;
}
//初始化仓库
list_poin init_Warehouse(list_poin head)
{
	FILE *fp = fopen("./log/Warehouse.txt", "r");
	char temp[100];
	char term[100] = "=============================";
	//创建头节点
	head = creat_head_node();
	//
	int i = 0;
	while(1)
	{
		list_poin new = creat_node();
		if(fscanf(fp, "%d  %s  %f  %f  %d\n", 
			&(new->num), new->good_name, &(new->bid), &(new->price), &(new->amount))
			==EOF  )
		{
			break;
		}
		link_node(head, new);
	}
	fclose(fp);
	return head;
}

// 0     写入仓库
// 1 进货单    老板
// 2 出货单	   顾客 
int write_txt(list_poin head , int i)
{
	
	char str[2] = "\n";
	list_poin p;
	p = head;
	FILE *fp =  NULL;

	char tim[50]; //时间
	char tim1[50];//临时时间存储

	date_time(&tim1);
	strcpy(tim, tim1);


	switch(i)
	{
		case 0 :fp = fopen("./log/Warehouse.txt", "w+");break;
		case 1 :fp = fopen("./log/add_txt.txt", "a+");break;
		case 2 :fp = fopen("./log/sub_txt.txt", "a+");break;
	}
	//写入仓库
	if(i==0)
	{
		while(p->next != head)
		{
			p = p->next;
			fprintf(fp, "%d  ", p->num);
			fprintf(fp, "%s  ", p->good_name);
			fprintf(fp, "%f  ", p->bid);
			fprintf(fp, "%f  ", p->price);
			fprintf(fp, "%d  ", p->amount);
			fprintf(fp, "%s", str);
		}
	}
	//写入进货单
	else if(i == 1)
	{

		while(p->next != head)
		{
			p = p->next;
			float temp = p->amount*p->bid;
			fprintf(fp, "%d ", p->num);
			fprintf(fp, "%s ", p->good_name);
			fprintf(fp, "%f ", p->bid);
			fprintf(fp, "%f ", p->price);
			fprintf(fp, "%d ", p->amount);
			fprintf(fp, "%f  ", -temp);
			fprintf(fp, "%s", tim);
			fprintf(fp, "%s", str);
		}
	}
	else if(i == 2)
	{

		while(p->next != head)
		{
			p = p->next;
			fprintf(fp, "%d ", p->num);
			fprintf(fp, "%s ", p->good_name);
			fprintf(fp, "%f ", p->bid);
			fprintf(fp, "%f ", p->price);
			fprintf(fp, "%d ", p->amount);
			fprintf(fp, "%f  ", p->amount*p->bid);
			fprintf(fp, "%s", tim);
			fprintf(fp, "%s", str);
		}
	}
	fclose(fp);
	return 0;
}

void write_user_txt(user_poin head)
{
	FILE *fp = fopen("./log/user_login.txt","w+");

	user_poin p = head;

	while(p->next != head)
	{
		p = p->next;
		fprintf(fp, "%s ", p->user_name);
		fprintf(fp, "%s ", p->user_password);
		fprintf(fp, "%d ", p->one_coupon);
		fprintf(fp, "%d ", p->hund_coupon);
		fprintf(fp, "%s", "\n");
	}
	fclose(fp);
}


//资金改变
//i参数：
//		1：加
//		0：减
void fund_change(float sub,int i)
{
	FILE *fp = fopen("./log/fund.txt", "r");
	float a;
	fscanf(fp, "%f", &a);
	fclose(fp);
	fp = fopen("./log/fund.txt", "w+");
	if(i)
		fprintf(fp, "%f\n", a+sub);
	else
		fprintf(fp, "%f\n", a-sub);	
	fclose(fp);
}

//资金查询
void find_fund()
{
	FILE *fp = fopen("./log/fund.txt", "r");
	float a;
	fscanf(fp, "%f", &a);
	fclose(fp);
	printfs_red("现有资金为 ：");
	printf("%0.1f\n" , a);
}

//该用户是否 已经被注册
//返回值
//		1：已经被注册
//		0: 没有被注册
int user_again(user_poin user,char z[])
{
	user_poin p =user;

	while(p->next != user)
	{
		p = p->next;
		if(!strcmp(p->user_name,z))
		{
			return 1;
		}
	}
	
	return 0;

}

//时间回传
void date_time( char (*tim1)[] )
{
	system("date > time.txt");
	FILE *fp = fopen("./time.txt", "r");
	char m[5][15];

	fscanf(fp, "%s %s %s %s %s", m[0], m[1], m[2], m[3], m[4]);
	sprintf(*tim1,"%s %s %s %s %s",m[0], m[1], m[2], m[3], m[4]);
	//printf("%s\n", *tim1);
	system("rm time.txt");
	fclose(fp);
}

//购物车结算 返回 购物车里面的价格
//i参数 	
//	1：老板用的
//	0：用户
float price_sub(list_poin head,int i)
{	
	list_poin p =head ;
	float num = 0;
	while(p->next != head)
	{
		p = p->next;
		if(i)
			num = num + p->amount * p->bid;	
		else
			num = num + p->amount * p->price;
	}
	return num;
}

//将顾客选的 东西 填入链表
list_poin buy_goods(list_poin head,int num)
{
	list_poin p = head;
	list_poin new = creat_node();

	for (int i = 0; i < num; ++i)
	{
		p = p->next;
	}
	if(p != head)
	{
		new->num = p->num;
		strcpy(new->good_name , p->good_name);
		new->bid = p->bid;
		new->price = p->price;
		new->amount = p->amount;
		return new;
	}
	return NULL;
}


//1:券减
//0：券加
//quan: 数量
void login_coupon_sub(user_poin head, char a[], char b[],int quan, int i)
{
	user_poin p = head;
	while(p->next != head)
	{
		p = p->next;
		if((!strcmp(p->user_name, a)) && (!strcmp(p->user_password, b)))
			break;
	}
	if(i)
		p->one_coupon = p->one_coupon - quan;
	else
		p->one_coupon = p->one_coupon + quan;

}

int login_coupon_return(user_poin head, char a[], char b[])
{
	user_poin p = head;
	while(p->next != head)
	{
		p = p->next;
		if((!strcmp(p->user_name, a)) && (!strcmp(p->user_password, b)))
			break;
	}
	return p->one_coupon;
}

int login_coupon(user_poin head, char a[], char b[])
{
	user_poin p = head;
	while(p->next != head)
	{
		p = p->next;
		if((!strcmp(p->user_name, a)) && (!strcmp(p->user_password, b)))
			break;
	}
	if(p->one_coupon != 0)
		return p->one_coupon;

	return  0;
}



//找节点，加仓库链表数量
//i参数
//		1：增加数量
//		0：减少数量
void num_change(list_poin  head, int  find, float num, int i)
{
	list_poin p = head;

	while(p->next != head)
	{
		if(p->num == find)
		{	
			if(i)
			{
				p->amount = p->amount+num;
			}
			else
			{
				p->amount = p->amount - num;
			}
			
		}			
		p = p->next;
	}
}

void sho_change(list_poin head, int num, int price)
{
	list_poin p = head;

	while(p->next != head)
	{
		if(p->num == num)
		{	
			p->price = price;
			break;
		}			
		p = p->next;
	}

}

