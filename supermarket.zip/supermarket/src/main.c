#include "double.h"
#include "menu.h"
#include "double.h"
#include "base.h"




int main(int argc, char const *argv[])
{

	menu_main();


	return 0;
}
