#ifndef __OPERATION_H__
#define __OPERATION_H__
#include <sys/ioctl.h>
#include <stdio.h>
#include <base.h>
#include <string.h>
#include <time.h>

//添加货源地商品
void add_goods();

//老板进货地方
void add_supermaket();

//顾客买东西
void sub_goods();

//用户登录
int login_user(user_poin head, char a[], char b[]);


//修改单个商品售价
void chang_price();


//整体价格调整，打折
void sale_menu();

//优惠券抢购操作
void Coupon(char a[], char b[]);


// //改变单个商品价格
// void chang_price( );

//账单查询
//i参数
//		1：进货账单
//		0：出货账单
void look_check(int i);

//用户注册
void enroll();

//资金查询
void look_fund();

//
// list_poin add_txt(list_poin head, list_poin add_h);
#endif