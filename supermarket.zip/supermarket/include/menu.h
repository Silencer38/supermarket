#ifndef _MENU_H
#define _MENU_H
#include <stdio.h>
#include <stdlib.h>
#include <operation.h>
#include <string.h>

//主界面
void menu_main();


//管理者使用界面
void keeper_menu();
//管理者登录界面
void keeper_login_menu();
//管理者登录操作
void keeper_login();


//用户使用界面
void Consumer_menu(char a[] ,char b[]);
//用户登录界面
void Consumer_login_menu();
//用户登录操作
void Consumer_login();




//红色字体
void printfs_red(char a[]);
//蓝色字体
void printfs_blue(char a[]);
//隐藏光标 提示语句
void hide_cursor();



#endif
