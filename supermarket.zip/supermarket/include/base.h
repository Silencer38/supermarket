#ifndef __BASE_SEQ__
#define __BASE_SEQ__

#include "double.h"
#include "menu.h"
#include "double.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//初始化仓库
list_poin init_Warehouse(list_poin head);
//初始化用户
user_poin init_User( user_poin user_head);
//将现有信息 写入 记事本
//i参数:
// 0 写入      仓库
// 1 进货单    老板
// 2 出货单	   顾客 
int write_txt(list_poin head , int i);
//将用户信息 写入 记事本
void write_user_txt(user_poin head);
//读取现有时间
//tim1:将时间写入该字符串
void date_time( char (*tim1)[] );
//资金改变
//i参数：
//		1：加
//		0：减
void fund_change(float sub,int i);
//资金查询
void find_fund();
//该用户是否 已经被注册
//返回值
//		1：已经被注册
int user_again(user_poin user,char z[]);
//购物车结算 返回 购物车里面的价格
//i参数 	
//	1：老板用的
//	0：用户
float price_sub(list_poin head,int i);
//将顾客选的 东西 填入链表   购物车   
//返回值：
//		单个东西商品的 节点
list_poin buy_goods(list_poin head,int num);


//找节点，加仓库链表数量
//i参数
//		1：增加数量
//		0：减少数量
void num_change(list_poin  head, int  find, float num, int i);
//单个售价修改
//num ： 商品编号
//price: 修改的价格
void sho_change(list_poin head, int num, int price);
//查看该用户是否有 优惠券
//返回值：
//		1：该用户有优惠券
//		0：该用户没有优惠券
int login_coupon(user_poin head, char a[], char b[]);

//返回该用户的 
//返回值：
//       优惠券的数量
int login_coupon_return(user_poin head, char a[], char b[]);

//优惠券的变更情况
//quan : 变更数量
//i参数：1/0
//		1：优惠券 减少
//	    0：优惠券 增加
void login_coupon_sub(user_poin head, char a[], char b[],int quan, int i);




#endif