#ifndef __DOUBLE_SEQ__
#define __DOUBLE_SEQ__

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
//商品节点链表
typedef struct goods
{
	// 商品编号
	int num;
	//商品名
	char good_name[100];
	//进价
	float bid;
	//售价
	float price;
	//数量
	int amount;

	struct goods *prev; 
	struct goods *next; 
	
}listnode, *list_poin;


//用户节点链表
typedef struct user_te
{
	//用户名
	char user_name[30];
	//用户密码
	char user_password[30];
	//1 元券
	int one_coupon;
	//100 减 20
	int hund_coupon;

	struct user_te *next; 

}user_mi, *user_poin;

/*=====================================用户链表==========================================

===================================================================================*/
//用户头结点
user_poin creat_head_user();
//用户节点
user_poin creat_node_user();
//用户节点链接
int link_node_user(user_poin head,user_poin temp);
//展示用户节点
int show_zheng_user(user_poin head);
//给用户展示的商品链表
//i参数：
//  	0：显示给顾客买的时候 的货物表
// 		1：显示  顾客买后 的确认表
int show_zheng_custom(list_poin head,int i);

/*=====================================商品链表==========================================

===================================================================================*/

//创建商品头节点
list_poin creat_head_node();
//创建商品节点
list_poin creat_node();
//商品节点链接
int link_node(list_poin head,list_poin temp);
//显示商品链表
int show_zheng_fu(list_poin head);

#endif